#!/bin/bash

function menu {
echo "TGN Smart Home"
echo "----------------"
echo "u  Update Linux"
echo "0. Exit"
echo "1. htop"
echo "2. screen -r"
echo "3. Reboot"
echo "4. Shutdown"
echo "5. stop mqtt service"
echo "6. stop sinric service"
echo "7. start mqtt service"
echo "8. start sinric service"

read answer
if [ "$answer" != "${answer#[u]}" ] ;then
sudo apt update
sudo apt upgrade
menu
fi
if [ "$answer" != "${answer#[0]}" ] ;then
exit
fi
if [ "$answer" != "${answer#[1]}" ] ;then
htop
menu
fi
if [ "$answer" != "${answer#[2]}" ] ;then
screen -r
menu
fi
if [ "$answer" != "${answer#[3]}" ] ;then
sudo reboot
fi
if [ "$answer" != "${answer#[4]}" ] ;then
sudo shutdown -h
exit
fi
if [ "$answer" != "${answer#[5]}" ] ;then
systemctl stop tgnmqtt
menu
fi
if [ "$answer" != "${answer#[6]}" ] ;then
systemctl stop sinric
menu
fi
if [ "$answer" != "${answer#[7]}" ] ;then
systemctl start tgnmqtt
menu
fi
if [ "$answer" != "${answer#[8]}" ] ;then
systemctl start sinric
menu
fi
}
menu
