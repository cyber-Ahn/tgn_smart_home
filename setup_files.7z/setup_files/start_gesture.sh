sudo python3 /home/pi/tgn_smart_home/libs/PAJ7620U2.py
