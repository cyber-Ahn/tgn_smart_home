sudo python3 /home/pi/tgn_smart_home/main_gui.py
