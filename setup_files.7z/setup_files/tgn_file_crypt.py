import os
from Crypto import Random
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import string
import random

chunks = 32 * 1024
def generate_sk():
    if not os.path.exists("secret_key.pem"):
        print("Generate Keys")
        key = RSA.generate(4096)
        with open("secret_key.pem", "wb") as f_out:
            f_out.write(key.export_key(format='PEM'))
        generate_pk()
        print("Keys ready")
    else:
        print("Keys available")
def import_key():
    with open("secret_key.pem", 'rb') as f_in:
        key = RSA.import_key(f_in.read())
    return key
def generate_pk():
    sk = import_key()
    pk = sk.publickey()
    with open("public_key.pem", "wb") as f_out:
        f_out.write(pk.export_key(format='PEM'))
    return pk
def encrypt(message):
    sk = import_key()
    pk = sk.publickey()
    cipher = PKCS1_OAEP.new(pk)
    c = cipher.encrypt(message)
    return c
def decrypt(c):
    sk = import_key()
    cipher = PKCS1_OAEP.new(sk)
    m = cipher.decrypt(c)
    return m
def get_key(password):
    hashing = SHA256.new(password.encode('utf-8'))
    return hashing.digest()
def sec_pwd(length=16):
    i=0
    random_password = ""
    string_constant = ""
    LETTERS = string.ascii_letters
    NUMBERS = string.digits
    PUNCTUATION = string.punctuation
    string_constant += NUMBERS
    string_constant += LETTERS
    string_constant += PUNCTUATION
    printable = list(string_constant)
    random.shuffle(printable)
    while i < length:
        random_password = random_password + random.choice(printable)
        i += 1
    random_password = ''.join(random_password)
    return random_password
def encrypt_file(filename):
    out_file_name = filename.split(".")[0] + ".tgn"
    out_file_key = filename.split(".")[0] + ".key"
    file_typ = (filename.split(".")[1]).zfill(16)
    file_size = str(os.path.getsize(filename)).zfill(16)
    IV = Random.new().read(16)
    key = sec_pwd(40)
    with open(out_file_key, 'wb') as f_ou:
        key_out = encrypt(str.encode(key))
        f_ou.write(key_out)
    encryptor = AES.new(get_key(key), AES.MODE_CFB, IV)
    with open(filename, 'rb') as f_input:
        with open(out_file_name, 'wb') as f_output:
            f_output.write(file_size.encode('utf-8'))
            f_output.write(IV)
            f_output.write(file_typ.encode('utf-8'))
            while True:
                chunk = f_input.read(chunks)
                if len(chunk) == 0:
                    break
                if len(chunk) % 16 != 0:
                    chunk += b' ' * (16 - (len(chunk) % 16))
                f_output.write(encryptor.encrypt(chunk))
def decrypt_file(file_name):
    key = ""
    file_key = file_name.split(".")[0] + ".key"
    with open(file_key, 'rb') as f_key:
        m = f_key.read()
        key = decrypt(m).decode('utf-8')
    with open(file_name, 'rb') as f_input:
        filesize = int(f_input.read(16))
        IV = f_input.read(16)
        file_typ = str(f_input.read(16)).split("'")[1].replace('0', '')
        out_file_name = file_name.split(".tgn")[0] + "_dec." + file_typ
        decryptor = AES.new(get_key(key), AES.MODE_CFB, IV)
        with open(out_file_name, 'wb') as f_output:
            while True:
                chunk = f_input.read(chunks)
                if len(chunk) == 0:
                    break
                f_output.write(decryptor.decrypt(chunk))
                f_output.truncate(filesize)
    os.remove(file_name.split(".")[0] + ".key")
    os.remove(file_name)
if __name__ == "__main__":
	generate_sk()